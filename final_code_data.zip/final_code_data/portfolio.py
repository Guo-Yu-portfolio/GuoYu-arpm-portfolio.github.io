import datetime
from scipy.stats import skew
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import quandl
import scipy.optimize as sco
from cffi.backend_ctypes import xrange
from pandas import DataFrame
from pandas.plotting import register_matplotlib_converters
import math
from scipy.stats import skew, kurtosis, kurtosistest
from scipy.stats import norm, t
from scipy.interpolate import UnivariateSpline
import seaborn as sns
#DATA
#
start = datetime.datetime.strptime("2018-10-01", "%Y-%m-%d")
end = datetime.datetime.strptime("2019-03-29", "%Y-%m-%d")
date_generated = [start + datetime.timedelta(days=x) for x in range(0, (end - start).days)]
# 6 month
colnames = ['date', 'lprice']
df = pd.read_csv('0.5_year.csv', names=colnames)
price4 = df.lprice.tolist()
date4 = df.date.tolist()
date4.remove('DATE')
price4.remove('DGS6MO')
# 1 year
colnames = ['date', 'lprice']
df = pd.read_csv('1_year.csv', names=colnames)
price1 = df.lprice.tolist()
date = df.date.tolist()
date.remove('DATE')
price1.remove('DGS1')
# 5 year
colnames = ['date', 'lprice']
df = pd.read_csv('5_year.csv', names=colnames)
price2 = df.lprice.tolist()
date2 = df.date.tolist()
date2.remove('DATE')
price2.remove('DGS5')
# 10 year
colnames = ['date', 'lprice']
df = pd.read_csv('10_year.csv', names=colnames)
price3 = df.lprice.tolist()
date3 = df.date.tolist()
date3.remove('DATE')
price3.remove('DGS10')
# 30 year
colnames = ['date', 'lprice']
df = pd.read_csv('30_year.csv', names=colnames)
price5 = df.lprice.tolist()
date5 = df.date.tolist()
date5.remove('DATE')
price5.remove('DGS30')
# AAPL
colnames = ['date','q','w','e','r','lprice','t']
df = pd.read_csv('aappl.csv', names=colnames)
price6 = df.lprice.tolist()
date6 = df.date.tolist()
# AMZN
colnames = ['date','q','w','e','r','lprice','t']
df = pd.read_csv('aamzn.csv', names=colnames)
price7 = df.lprice.tolist()
date7 = df.date.tolist()
# GOOGL
colnames = ['date','q','w','e','r','lprice','t']
df = pd.read_csv('ggoogl.csv', names=colnames)
price8 = df.lprice.tolist()
date8= df.date.tolist()
# FB
colnames = ['date','q','w','e','r','lprice','t']
df = pd.read_csv('FB (3).csv', names=colnames)
price9 = df.lprice.tolist()
date9 = df.date.tolist()
# NFLX
colnames = ['date','q','w','e','r','lprice','t']
df = pd.read_csv('nnflx.csv', names=colnames)
price10 = df.lprice.tolist()
date10 = df.date.tolist()
# usdcnh
colnames = ['date','lprice']
df = pd.read_csv('usdcnh.csv', names=colnames)
price11 = df.lprice.tolist()
date11 = df.date.tolist()
price11.reverse()
date11.reverse()
# usdjpy
colnames = ['date','lprice']
df = pd.read_csv('usdjpy.csv', names=colnames)
price12 = df.lprice.tolist()
date12 = df.date.tolist()
price12.reverse()
date12.reverse()
# gbpusd
colnames = ['date','lprice']
df = pd.read_csv('GBPUSD.csv', names=colnames)
price13 = df.lprice.tolist()
date13 = df.date.tolist()
price13.reverse()
date13.reverse()
# eurusd
colnames = ['date','lprice']
df = pd.read_csv('eurusd.csv', names=colnames)
price14 = df.lprice.tolist()
date14 = df.date.tolist()
price14.reverse()
date14.reverse()
#MISSING DATA
def missing_data(price,date):
    date_pre = []
    for i in range(len(date)):
        date_pre.append(datetime.datetime.strptime(date[i], "%Y-%m-%d"))
    missing_date = []
    missing_data = []
    real_date = []
    real_price = []

    for i in range(len(date_pre)):
        if price[i] == '.':
            missing_data.append(i)

    for i in range(len(missing_data)):
        del date_pre[missing_data[len(missing_data) - 1 - i]]
        del price[missing_data[len(missing_data) - 1 - i]]

    for i in range(len(date_generated)):
        if date_generated[i] == date_pre[i - len(missing_date)]:
            real_date.append(i)
            real_price.append(float(price[i - len(missing_date)]))
        else:
            missing_date.append(i)

    spline = UnivariateSpline(real_date, real_price)

    for i in range(len(missing_date)):
        real_price.insert(missing_date[i], float(spline(missing_date[i])))
    return real_price
price_5mo = missing_data(price4,date4)
price_1year = missing_data(price1,date)
price_5year = missing_data(price2,date2)
price_10year = missing_data(price3,date3)
price_30year = missing_data(price5,date5)
price_aapl = missing_data(price6,date6)
price_amzn = missing_data(price7,date7)
price_googl = missing_data(price8,date8)
price_fb = missing_data(price9,date9)
price_nflx = missing_data(price10,date10)
price_usdcnh = missing_data(price11,date11)
price_usdjpy = missing_data(price12,date12)
price_gbpusd = missing_data(price13,date13)
price_eurusd = missing_data(price14,date14)
initial_tablel1 = {'5mo':price_5mo, '1year': price_1year, '5year': price_5year, '10year': price_10year, '30year': price_30year, 'aapl':price_aapl, 'amzn': price_amzn, 'googl':price_googl,'fb':price_fb,'nflx':price_nflx,'usdcnh':price_usdcnh,'usdjpy':price_usdjpy,'gbpusd':price_gbpusd,'eurusd':price_eurusd,'date': date_generated}
second_table1 = DataFrame(data=initial_tablel1)
final_table1 = second_table1.set_index('date')
#
###
###
def exp_decay_fp(t_, tau_hl, t_star=None):
    """For details, see [here](https://www.arpm.co/lab/redirect.php?permalink=exp_decay_fp).

    Parameters
    ----------
        t_ : scalar
        tau_hl : scalar
        t_star: scalar, optional
    Returns
    -------
        p array, shape(t_, )

    """

    if t_star is None:
        t_star = t_

    # compute probabilities
    p = np.exp(-(np.log(2) / tau_hl) * abs(t_star - np.arange(0, t_)))
    # rescale
    p = p / np.sum(p)
    return p

def simulate_rw_hfp(x_t_now, epsi, p=None, j_=1, m_=1):
    """For details, see [here](https://www.arpm.co/lab/redirect.php?permalink=simulate_rw_hfp).

    Parameters
    ----------
        x_t_now : array, shape(i_, )
        epsi : array, shape(t_, i_)
        p : array, shape(t_, )
        j_ : int
        m_ : int

    Returns
    -------
        x_tnow_thor : array, shape(j_, m_ + 1, i_)

    """

    if p is None:
        t_ = epsi.shape[0]
        p = np.ones(t_) / t_

    i_ = x_t_now.shape[0]
    x_tnow_thor = np.zeros((j_, m_ + 1, i_))
    x_tnow_thor[:, 0, :] = x_t_now

    for m in range(1, m_ + 1):
        # Step 1: Compute invariants via bootstraping

        epsi_j = bootstrap_hfp(epsi, p, j_)

        # Step 2: Compute projected path

        x_tnow_thor[:, m, :] = x_tnow_thor[:, m - 1, :] + epsi_j

    return x_tnow_thor

############
###########

def bootstrap_hfp(epsi, p=None, j_=1000):
    """For details, see [here](https://www.arpm.co/lab/redirect.php?permalink=eb-bootfunc).

    Parameters
    ----------
        epsi : array, shape (t_, i_)
        p : array, shape (t_, )
        j_ : int

    Returns
    -------
        epsi_j : array, shape(j_, i_)

    """

    if len(epsi.shape) == 1:
        epsi = epsi.reshape(-1, 1)
    t_, i_ = epsi.shape

    if p is None:
        p = np.ones(t_) / t_

    # Step 1: Compute subintervals

    s = np.r_[np.array([0]), np.cumsum(p)]

    # Step 2: Draw scenarios from uniform distribution

    u = np.random.rand(j_)

    # Step 3: Compute invariant scenarios

    ind = np.digitize(u, bins=s) - 1
    epsi_j = epsi[ind, :]

    return epsi_j

def estimation_projection(price1):
    epsi = np.diff(np.log(price1))
    tau_hl=30
    m_ = 10  # number of monitoring times
    j_ = 1000  # number of scenarios
    x = np.log(np.array(price1))
    t_ = len(epsi)
    t_star = t_
    p_exp = exp_decay_fp(t_, tau_hl, t_star)
    x_tnow_thor = simulate_rw_hfp(x[-1].reshape(1), epsi, p_exp, j_, m_).squeeze()
    testing = []
    for i in range(0,len(x_tnow_thor)):
        test = np.diff(x_tnow_thor[i])
        testing.append(test)
    flatten_list = [j for sub in testing for j in sub]
    return flatten_list
#
p1 = estimation_projection(price_5mo)
p2 = estimation_projection(price_1year)
p3 = estimation_projection(price_5year)
p4 = estimation_projection(price_10year)
p5 = estimation_projection(price_30year)
p6 = estimation_projection(price_aapl)
p7 = estimation_projection(price_amzn)
p8 = estimation_projection(price_googl)
p9 = estimation_projection(price_fb)
p10 = estimation_projection(price_nflx)
p11 = estimation_projection(price_usdcnh)
p12 = estimation_projection(price_usdjpy)
p13 = estimation_projection(price_gbpusd)
p14 = estimation_projection(price_eurusd)
#############################################
start1 = datetime.datetime.strptime("2018-10-01", "%Y-%m-%d")
end1 = datetime.datetime.strptime("2046-2-16", "%Y-%m-%d")
date_generatedd = [start1 + datetime.timedelta(days=x) for x in range(0, (end1 - start1).days)]
initial_tablel = {'5mo':p1, '1year': p2, '5year': p3, '10year': p4, '30year': p5, 'aapl':p6, 'amzn': p7, 'googl':p8,'fb':p9,'nflx':p10,'usdcnh':p11,'usdjpy':p12,'gbpusd':p13,'eurusd':p14,'date': date_generatedd}
second_table = DataFrame(data=initial_tablel)
final_table = second_table.set_index('date')
#######################



register_matplotlib_converters()

plt.style.use('fivethirtyeight')
np.random.seed(777)

quandl.ApiConfig.api_key = '8smx_85mZ4zyRk_DAfNX'
stocks = ['AAPL', 'AMZN', 'GOOGL', 'FB','NFLX']
data = quandl.get_table('WIKI/PRICES', ticker=stocks,
                        qopts={'columns': ['date', 'ticker', 'adj_close']},
                        date={'gte': '2018-1-1', 'lte': '2019-6-1'}, paginate=True)
data.head()

df = data.set_index('date')

df.head()
#######################

# 5
table = final_table
# By specifying col[1] in below list comprehension
# You can select the stock names under multi-level column
table.columns = [col[1] for col in table.columns]
table.head()
# 6

# 7


# 8
returns = final_table
mean_returns = returns.mean()
cov_matrix = returns.cov()
##############
returns1 = final_table1.pct_change()
mean_returns1 = returns1.mean()
cov_matrix1 = returns1.cov()
###############
num_portfolios = 25000
risk_free_rate = 0.0178
def portfolio_annualised_performance(weights, mean_returns, cov_matrix):
    returns = np.sum(mean_returns * weights) * 252
    std = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))) * np.sqrt(252)

    return std, returns

def portfolio_performance(weights, mean_returns, cov_matrix):
    returns = np.sum(mean_returns * weights)
    std = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    return std, returns

def weight_combination(num_portfolios, mean_returns, cov_matrix, risk_free_rate, target):
    results = np.zeros((3, num_portfolios))
    weights_record = []
    for i in xrange(num_portfolios):
        weights = np.random.random(14)
        weights /= np.sum(weights)

        portfolio_std_dev, portfolio_return = portfolio_annualised_performance(weights, mean_returns, cov_matrix)
        if portfolio_std_dev < target:
            results[0, i] = portfolio_std_dev
            results[1, i] = portfolio_return
            results[2, i] = (portfolio_return - risk_free_rate) / portfolio_std_dev
            weights_record.append(weights)
    return results, weights_record
# 9

def short_fall(num_portfolios, mean_returns, cov_matrix, risk_free_rate, target):
    results = np.zeros((3, num_portfolios))
    weights_record = []
    cVAR_record = []
    for i in xrange(num_portfolios):
        weights = np.random.random(14)
        weights /= np.sum(weights)

        portfolio_std_dev, portfolio_return = portfolio_annualised_performance(weights, mean_returns, cov_matrix)
        if portfolio_std_dev < target:
            results[0, i] = portfolio_std_dev
            results[1, i] = portfolio_return
            results[2, i] = (portfolio_return - risk_free_rate) / portfolio_std_dev
            weights_record.append(weights)
            h = 10.  # horizon of 10 days
            mu_h = portfolio_return # this is the mean of % returns over 10 days - 10%
            sig_h = portfolio_std_dev  # this is the vol over the horizon
            alpha = 0.01
        # ppf is the percent point function, inverse of CDF
        # here we have a mean=0, sd=1 distribution
        # as we have not specified the shape in ppf
        # So you can think of this as upscaling by sig_h and shifting mean by mu_h
            VaR_n = norm.ppf(1 - alpha) * sig_h - mu_h
            CVaR_n = alpha ** -1 * norm.pdf(norm.ppf(alpha)) * sig_h - mu_h
            cVAR_record.append(round(CVaR_n * 100, 2))
    return cVAR_record, weights_record, results


#

def random_portfolios(num_portfolios, mean_returns, cov_matrix, risk_free_rate):
    results = np.zeros((3,num_portfolios))
    weights_record = []
    for i in xrange(num_portfolios):
        weights = np.random.random(14)
        weights /= np.sum(weights)
        weights_record.append(weights)
        portfolio_std_dev, portfolio_return = portfolio_annualised_performance(weights, mean_returns, cov_matrix)
        results[0,i] = portfolio_std_dev
        results[1,i] = portfolio_return
        results[2,i] = (portfolio_return - risk_free_rate) / portfolio_std_dev
    return results, weights_record


# 10

# 11
def display_simulated_ef_with_random(mean_returns, cov_matrix, num_portfolios, risk_free_rate):
    results, weights = random_portfolios(num_portfolios, mean_returns, cov_matrix, risk_free_rate)

    max_sharpe_idx = np.argmax(results[2])
    sdp, rp = results[0, max_sharpe_idx], results[1, max_sharpe_idx]
    max_sharpe_allocation = pd.DataFrame(weights[max_sharpe_idx], index=table.columns, columns=['allocation'])
    max_sharpe_allocation.allocation = [round(i * 100, 2) for i in max_sharpe_allocation.allocation]
    max_sharpe_allocation = max_sharpe_allocation.T

    min_vol_idx = np.argmin(results[0])
    sdp_min, rp_min = results[0, min_vol_idx], results[1, min_vol_idx]
    min_vol_allocation = pd.DataFrame(weights[min_vol_idx], index=table.columns, columns=['allocation'])
    min_vol_allocation.allocation = [round(i * 100, 2) for i in min_vol_allocation.allocation]
    min_vol_allocation = min_vol_allocation.T

    print("-" * 80)
    print("Maximum Sharpe Ratio Portfolio Allocation\n")
    print("Annualised Return:", round(rp, 2))
    print("Annualised Volatility:", round(sdp, 2))
    print("\n")
    print(max_sharpe_allocation)
    print("-" * 80)
    print("Minimum Volatility Portfolio Allocation\n")
    print("Annualised Return:", round(rp_min, 2))
    print("Annualised Volatility:", round(sdp_min, 2))
    print("\n")
    print(min_vol_allocation)

    plt.figure(figsize=(10, 7))
    plt.scatter(results[0, :], results[1, :], c=results[2, :], cmap='YlGnBu', marker='o', s=10, alpha=0.3)
    plt.colorbar()
    plt.scatter(sdp, rp, marker='*', color='r', s=500, label='Maximum Sharpe ratio')
    plt.scatter(sdp_min, rp_min, marker='*', color='g', s=500, label='Minimum volatility')
    plt.title('Simulated Portfolio Optimization based on Efficient Frontier')
    plt.xlabel('annualised volatility')
    plt.ylabel('annualised returns')
    plt.legend(labelspacing=0.8)
    plt.show()
    return max_sharpe_allocation,min_vol_allocation

    # 12

results, weight = weight_combination(num_portfolios,mean_returns, cov_matrix, 0.0178,0.4)

#print(len(weight))
maxi,mini = display_simulated_ef_with_random(mean_returns1, cov_matrix1, num_portfolios, 0.0178)

Cvar,weights,results = short_fall(num_portfolios,mean_returns, cov_matrix, 0.0178,0.1)

index_number = Cvar.index(min(Cvar))
minCvar_weight = weights[index_number]
print(minCvar_weight)
# 13

def neg_sharpe_ratio(weights, mean_returns, cov_matrix, risk_free_rate):
    p_var, p_ret = portfolio_annualised_performance(weights, mean_returns, cov_matrix)
    return -(p_ret - risk_free_rate) / p_var


def max_sharpe_ratio(mean_returns, cov_matrix, risk_free_rate):
    num_assets = len(mean_returns)
    args = (mean_returns, cov_matrix, risk_free_rate)
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bound = (0.0, 1.0)
    bounds = tuple(bound for asset in range(num_assets))
    result = sco.minimize(neg_sharpe_ratio, num_assets * [1. / num_assets, ], args=args,
                          method='SLSQP', bounds=bounds, constraints=constraints)
    return result


# 14
def portfolio_volatility(weights, mean_returns, cov_matrix):
    return portfolio_annualised_performance(weights, mean_returns, cov_matrix)[0]


def min_variance(mean_returns, cov_matrix):
    num_assets = len(mean_returns)
    args = (mean_returns, cov_matrix)
    constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bound = (0.0, 1.0)
    bounds = tuple(bound for asset in range(num_assets))

    result = sco.minimize(portfolio_volatility, num_assets * [1. / num_assets, ], args=args,
                          method='SLSQP', bounds=bounds, constraints=constraints)

    return result


# 15

def efficient_return(mean_returns, cov_matrix, target):
    num_assets = len(mean_returns)
    args = (mean_returns, cov_matrix)

    def portfolio_return(weights):
        return portfolio_annualised_performance(weights, mean_returns, cov_matrix)[1]

    constraints = ({'type': 'eq', 'fun': lambda x: portfolio_return(x) - target},
                   {'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
    bounds = tuple((0, 1) for asset in range(num_assets))
    result = sco.minimize(portfolio_volatility, num_assets * [1. / num_assets, ], args=args, method='SLSQP',
                          bounds=bounds, constraints=constraints)
    return result


def efficient_frontier(mean_returns, cov_matrix, returns_range):
    efficients = []
    for ret in returns_range:
        efficients.append(efficient_return(mean_returns, cov_matrix, ret))
    return efficients


# 16
def display_calculated_ef_with_random(mean_returns, cov_matrix, num_portfolios, risk_free_rate):
    results, _ = random_portfolios(num_portfolios, mean_returns, cov_matrix, risk_free_rate)

    max_sharpe = max_sharpe_ratio(mean_returns, cov_matrix, risk_free_rate)
    sdp, rp = portfolio_annualised_performance(max_sharpe['x'], mean_returns, cov_matrix)
    max_sharpe_allocation = pd.DataFrame(max_sharpe.x, index=table.columns, columns=['allocation'])
    max_sharpe_allocation.allocation = [round(i * 100, 2) for i in max_sharpe_allocation.allocation]
    max_sharpe_allocation = max_sharpe_allocation.T
    max_sharpe_allocation

    min_vol = min_variance(mean_returns, cov_matrix)
    sdp_min, rp_min = portfolio_annualised_performance(min_vol['x'], mean_returns, cov_matrix)
    min_vol_allocation = pd.DataFrame(min_vol.x, index=table.columns, columns=['allocation'])
    min_vol_allocation.allocation = [round(i * 100, 2) for i in min_vol_allocation.allocation]
    min_vol_allocation = min_vol_allocation.T

    plt.figure(figsize=(10, 7))
    plt.scatter(results[0, :], results[1, :], c=results[2, :], cmap='YlGnBu', marker='o', s=10, alpha=0.3)
    plt.colorbar()
    plt.scatter(sdp, rp, marker='*', color='r', s=500, label='Maximum Sharpe ratio')
    plt.scatter(sdp_min, rp_min, marker='*', color='g', s=500, label='Minimum volatility')

    target = np.linspace(rp_min, 0.32, 50)
    efficient_portfolios = efficient_frontier(mean_returns, cov_matrix, target)
    plt.plot([p['fun'] for p in efficient_portfolios], target, linestyle='-.', color='black',
             label='efficient frontier')
    plt.title('Calculated Portfolio Optimization based on Efficient Frontier')
    plt.xlabel('annualised volatility')
    plt.ylabel('annualised returns')
    plt.legend(labelspacing=0.8)
    plt.show()
    return max_sharpe_allocation
    # 17


#max = display_calculated_ef_with_random(mean_returns1, cov_matrix1, num_portfolios, risk_free_rate)


# 20
def display_ef_with_selected(mean_returns, cov_matrix, risk_free_rate):
    max_sharpe = max_sharpe_ratio(mean_returns, cov_matrix, risk_free_rate)
    sdp, rp = portfolio_annualised_performance(max_sharpe['x'], mean_returns, cov_matrix)
    max_sharpe_allocation = pd.DataFrame(max_sharpe.x, index=table.columns, columns=['allocation'])
    max_sharpe_allocation.allocation = [round(i * 100, 2) for i in max_sharpe_allocation.allocation]
    max_sharpe_allocation = max_sharpe_allocation.T
    max_sharpe_allocation

    min_vol = min_variance(mean_returns, cov_matrix)
    sdp_min, rp_min = portfolio_annualised_performance(min_vol['x'], mean_returns, cov_matrix)
    min_vol_allocation = pd.DataFrame(min_vol.x, index=table.columns, columns=['allocation'])
    min_vol_allocation.allocation = [round(i * 100, 2) for i in min_vol_allocation.allocation]
    min_vol_allocation = min_vol_allocation.T

    an_vol = np.std(returns) * np.sqrt(252)
    an_rt = mean_returns * 252

    print("-" * 80)
    print("Maximum Sharpe Ratio Portfolio Allocation\n")
    print("Annualised Return:", round(rp, 2))
    print("Annualised Volatility:", round(sdp, 2))
    print("\n")
    print(max_sharpe_allocation)
    print("-" * 80)
    print("Minimum Volatility Portfolio Allocation\n")
    print("Annualised Return:", round(rp_min, 2))
    print("Annualised Volatility:", round(sdp_min, 2))
    print("\n")
    print(min_vol_allocation)
    print("-" * 80)
    print("Individual Stock Returns and Volatility\n")
    for i, txt in enumerate(table.columns):
        print(txt, ":", "annuaised return", round(an_rt[i], 2), ", annualised volatility:", round(an_vol[i], 2))
    print("-" * 80)

    fig, ax = plt.subplots(figsize=(10, 7))
    ax.scatter(an_vol, an_rt, marker='o', s=200)

    for i, txt in enumerate(table.columns):
        ax.annotate(txt, (an_vol[i], an_rt[i]), xytext=(10, 0), textcoords='offset points')
    ax.scatter(sdp, rp, marker='*', color='r', s=500, label='Maximum Sharpe ratio')
    ax.scatter(sdp_min, rp_min, marker='*', color='g', s=500, label='Minimum volatility')

    target = np.linspace(rp_min, 0.34, 50)
    efficient_portfolios = efficient_frontier(mean_returns, cov_matrix, target)
    ax.plot([p['fun'] for p in efficient_portfolios], target, linestyle='-.', color='black', label='efficient frontier')
    ax.set_title('Portfolio Optimization with Individual Stocks')
    ax.set_xlabel('annualised volatility')
    ax.set_ylabel('annualised returns')
    ax.legend(labelspacing=0.8)
    plt.show()


# 21
#display_ef_with_selected(mean_returns1, cov_matrix1, risk_free_rate)
def distribution(weight,table):
    results = table@weight
    results.sum(level='date')
    return results
def future_data(weight):
    colnames = ['date','googl','amzn','aapl','fb','nflx','eurusd','usdcnh','usdjpy','gbpusd','year10', 'year0', 'year1', 'year5','year30']
    df = pd.read_csv('back2.csv', names=colnames)
    date = df.date.tolist()
    dates_list = []
    for i in range(len(date)):
        dates_list.append(datetime.datetime.strptime(date[i], "%m/%d/%Y"))
    p1 = df.year0.tolist()
    p2 = df.year1.tolist()
    p3 = df.year5.tolist()
    p4 = df.year10.tolist()
    p5 = df.year30.tolist()
    p6 = df.aapl.tolist()
    p7 = df.amzn.tolist()
    p8 = df.googl.tolist()
    p9 = df.fb.tolist()
    p10 = df.nflx.tolist()
    p11 = df.usdcnh.tolist()
    p12 = df.usdjpy.tolist()
    p13 = df.gbpusd.tolist()
    p14 = df.eurusd.tolist()
    initial_tablel = {'5mo': p1, '1year': p2, '5year': p3, '10year': p4, '30year': p5, 'aapl': p6, 'amzn': p7,
                      'googl': p8, 'fb': p9, 'nflx': p10, 'usdcnh': p11, 'usdjpy': p12, 'gbpusd': p13, 'eurusd': p14,
                      'date': dates_list}
    second_table = DataFrame(data=initial_tablel)
    final_table = second_table.set_index('date')
    result = final_table.pct_change()
    result.loc[:, 'usdcnh'] *= 10
    result.loc[:, 'usdjpy'] *= 10
    result.loc[:, 'gbpusd'] *= 10
    result.loc[:, 'eurusd'] *= 10
    final_results = result@weight
    project = final_results.sum(level='date')
    project += 1
    project = project.cumprod()
    project.plot()
    plt.show()
    print(project)



equal_weight = [0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857,
                    0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857, 0.07142857]
future_data(minCvar_weight)
future_data(equal_weight)
future_data(maxi)
future_data(mini)
dis = distribution(minCvar_weight,final_table)
equ = distribution(equal_weight,final_table)
dis1 = distribution(maxi,final_table)
equ1 = distribution(mini,final_table)
ax = dis.plot.hist(bins = 100,color='r')
bx = equ.plot.hist(bins = 100,color='b')

plt.show()
