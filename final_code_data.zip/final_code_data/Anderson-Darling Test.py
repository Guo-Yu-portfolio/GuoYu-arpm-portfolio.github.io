
# Anderson-Darling Test
from numpy.random import seed
from numpy.random import randn
from scipy.stats import anderson
import math
import pandas as dy
# seed the random number generator
colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('NFLX.csv', names=colnames)
price = df.lprice.tolist()
date = df.date.tolist()
price.reverse()
date.reverse()

price1 = []
price2 = []
price3 = []
result = anderson(price1)
print('Statistic: %.3f' % result.statistic)
p = 0
for i in range(len(result.critical_values)):
	sl, cv = result.significance_level[i], result.critical_values[i]
	if result.statistic < result.critical_values[i]:
		print('%.3f: %.3f, data looks normal (fail to reject H0)' % (sl, cv))
	else:
		print('%.3f: %.3f, data does not look normal (reject H0)' % (sl, cv))