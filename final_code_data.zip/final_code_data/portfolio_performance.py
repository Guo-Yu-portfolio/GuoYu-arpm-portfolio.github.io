import pandas as dy
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
colnames = ['year1','year5','year10','eurusd','usdjpy','usdcnh','googl','amzn','fb']
df = dy.read_csv('BOOK1.csv', names=colnames)
p1 = df.year1.tolist()
p2 = df.year5.tolist()
p3 = df.year10.tolist()
p4 = df.eurusd.tolist()
p5 = df.usdjpy.tolist()
p6 = df.usdcnh.tolist()
p7 = df.googl.tolist()
p8 = df.amzn.tolist()
p9 = df.fb.tolist()
price1 = []
price2 = []
price3 = []
price4 = []
price5 = []
price6 = []
price7 = []
price8 = []
price9 = []
price10 = []
price11 = []
for i in range(178):
    price1.append(1)
    price2.append(1)
    price3.append(1)
    price4.append(1)
    price5.append(1)
    price6.append(1)
    price7.append(1)
    price8.append(1)
    price9.append(1)

    #price1[i] = math.log(price[i+1]/price[i])
    price1[i] = (p1[i+1]/p1[i])-1
    price2[i] = (p2[i + 1] / p2[i]) - 1
    price3[i] = (p3[i + 1] / p3[i]) - 1
    price4[i] = (p4[i + 1] / p4[i]) - 1
    price5[i] = (p5[i + 1] / p5[i]) - 1
    price6[i] = (p6[i + 1] / p6[i]) - 1
    price7[i] = (p7[i + 1] / p7[i]) - 1
    price8[i] = (p8[i + 1] / p8[i]) - 1
    price9[i] = (p9[i + 1] / p9[i]) - 1
    #price3[i] = price1[i]-price2[i]
for i in range(178):
    price10.append(1)
    price11.append(1)
    price10[i] = (price1[i]+price2[i]+price3[i]+price4[i]+price5[i]+price6[i]+price7[i]+price8[i]+price9[i])/9
    price11[i] = price10[i] + 0.02
sns.distplot(price10);
#plt.hist(price11, color = 'blue', edgecolor = 'black',
        # bins = int(180/5))
plt.show()