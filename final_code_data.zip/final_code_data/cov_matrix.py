import pandas as dy
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('amzn.csv', names=colnames)
price1 = df.lprice.tolist()

colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('googl.csv', names=colnames)
price2 = df.lprice.tolist()

colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('fb.csv', names=colnames)
price3 = df.lprice.tolist()

colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('AAPL.csv', names=colnames)
price4 = df.lprice.tolist()

colnames = ['date', 'lprice', 'vol', 's']
df = dy.read_csv('NFLX.csv', names=colnames)
price5 = df.lprice.tolist()
label = ["AMZN","GOOGL","FB","AAPL","NFLX"]
print(price1)
x = np.array([price1, price2,price3,price4,price5])
corr_mat = np.corrcoef(x)
print(corr_mat)
ax = sns.heatmap(
    corr_mat,
    vmin=-1, vmax=1, center=0,
    cmap=sns.diverging_palette(20, 220, n=200),
    square=True
)
ax.set_xticklabels(
    ax.get_xticklabels(),
    rotation=45,
    horizontalalignment='right'
)
ax.set_xticklabels(label)
ax.set_yticklabels(label)
plt.show(ax)