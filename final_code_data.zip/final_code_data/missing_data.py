import datetime
import pandas as dy
import xlwt
from tempfile import TemporaryFile
from scipy.interpolate import UnivariateSpline
from matplotlib import pyplot as plt

start = datetime.datetime.strptime("2018-10-01", "%Y-%m-%d")
end = datetime.datetime.strptime("2019-03-29", "%Y-%m-%d")
date_generated = [start + datetime.timedelta(days=x) for x in range(0, (end - start).days)]

colnames = ['date', 'lprice']
df = dy.read_csv('1_year.csv', names=colnames)
price1 = df.lprice.tolist()
date = df.date.tolist()
date.remove('DATE')
price1.remove('DGS1')
date_pre = []
for i in range(len(date)):
    date_pre.append(datetime.datetime.strptime(date[i], "%Y-%m-%d"))

missing_date = []
missing_data = []
real_date = []
real_price = []

for i in range(len(date_pre)):
    if price1[i] == '.':
        missing_data.append(i)

for i in range(len(missing_data)):
    del date_pre[missing_data[len(missing_data) - 1 - i]]
    del price1[missing_data[len(missing_data) - 1 - i]]

for i in range(len(date_generated)):
    if date_generated[i] == date_pre[i - len(missing_date)]:
        real_date.append(i)
        real_price.append(float(price1[i - len(missing_date)]))
    else:
        missing_date.append(i)

spline = UnivariateSpline(real_date, real_price)
plt.plot(real_price)
for i in range(len(missing_date)):
    real_price.insert(missing_date[i], float(spline(missing_date[i])))

print(real_price)
print(missing_date)
book = xlwt.Workbook()
sheet1 = book.add_sheet('sheet1')

for i, e in enumerate(real_price):
    sheet1.write(i, 0, e)

name = "random.xls"
book.save(name)
book.save(TemporaryFile())
plt.plot(real_price)
plt.show()